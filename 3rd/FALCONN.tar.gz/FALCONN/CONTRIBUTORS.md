### Contributors

FALCONN has been created by [Ilya Razenshteyn](http://ilyaraz.org/)
and [Ludwig Schmidt](https://people.csail.mit.edu/ludwigs/).
FALCONN grew out of a joint research project with
[Alexandr Andoni](http://www.mit.edu/~andoni/),
[Piotr Indyk](https://people.csail.mit.edu/indyk/),
and [Thijs Laarhoven](http://thijs.com/).

We thank the following people who helped us with finding bugs and
testing:
* [Grey Ballard](http://www.sandia.gov/~gmballa/)
* [Ranjit Chacko](https://github.com/rjchacko)
* [Dhiraj Holden](http://toc.csail.mit.edu/user/237)
* Ilya Kornakov
* Weiwei Liu
* [Piero Molino](https://github.com/w4nderlust)
* [Marcel Ruegenberg](https://github.com/mruegenberg)
* [Andrew Sabisch](http://www.jamoozy.com/index.html)
* [Charlampos Tsourakakis](http://people.seas.harvard.edu/~babis/)